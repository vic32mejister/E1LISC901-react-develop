import {Typography} from "@mui/material";
import SideNav from "./SideNav.jsx";

function ListaProductos(){

    return(
        <>
            <SideNav/>
            <Typography>Productos</Typography>
        </>
    )

}

export default ListaProductos;